﻿Public Class menu
    Private Sub menu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim CursorX As Icon
        CursorX = My.Resources.cursor
        Me.Cursor = New Cursor(CursorX.Handle)
    End Sub

    Private Sub Label1_A(sender As Object, e As EventArgs) Handles Label1.MouseEnter
        Label1.ForeColor = Color.Yellow
    End Sub
    Private Sub Label1_B(sender As Object, e As EventArgs) Handles Label1.MouseLeave
        Label1.ForeColor = Color.White
    End Sub
End Class